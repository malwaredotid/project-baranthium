#pragma once
#include "../../sdk/common.h"

class CVisuals {
public:
	void PlayerESP(uintptr_t, uintptr_t);
};
inline CVisuals gVisuals;